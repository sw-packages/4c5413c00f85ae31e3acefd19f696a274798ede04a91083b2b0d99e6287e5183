// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

//! [0]
menubar->addMenu(fileMenu);
//! [0]


//! [1]
QMenuBar *menuBar = new QMenuBar(nullptr);
//! [1]
